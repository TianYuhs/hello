**TG_PUSH教程**

如何获取token以及UserID

Ⅰ.首先在Telegram上搜索[BotFather](https://t.me/BotFather)机器人<br>

![TG_PUSH1](https://gitee.com/lxk0301/jd_docker/raw/master/icon/TG_PUSH1.png)

Ⅱ.利用[BotFather](https://t.me/BotFather)创建一个属于自己的通知机器人，按照下图中的1、2、3步骤拿到token，格式形如```10xxx4:AAFcqxxxxgER5uw```。<br>

![TG_PUSH2](https://gitee.com/lxk0301/jd_docker/raw/master/icon/TG_PUSH2.png)<br>

**新创建的机器人需要跟它发一条消息来开启对话，否则可能会遇到PEKY填对了但是收不到消息的情况**<br>

Ⅲ.再次在Telegram上搜索[getuserIDbot](https://t.me/getuserIDbot)机器人，获取UserID。<br>

![TG_PUSH3](https://gitee.com/lxk0301/jd_docker/raw/master/icon/TG_PUSH3.png)
